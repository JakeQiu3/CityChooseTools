//
//  LMContainsLMComboxScrollView.h
//  YouLan
//
//  Created by qsy on 14-8-14.
//  Copyright (c) 2014年 qsy. All rights reserved.
//  包含LMComboxView类型的子视图的UIScollView

 

#import <UIKit/UIKit.h>

@interface LMContainsLMComboxScrollView : UIScrollView

-(void)closeAllTheComBoxView;

@end
