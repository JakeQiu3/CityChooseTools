//
//  LMMainViewController.h
//  LMComBoxView
//
//  Created by qsy on 14-8-15.
//  Copyright (c) 2014年 qsy. All rights reserved.
//

 

#import <UIKit/UIKit.h>
#import "LMComBoxView.h"

@interface LMMainViewController : UIViewController<LMComBoxViewDelegate>

@end
