//
//  BSAreaPickerView.h
//  bs1369
//
//  Created by qsy on 15/11/10.
//  Copyright (c) 2015年 qsy. All rights reserved.
//

#import <UIKit/UIKit.h>
@class BSAreaPickerView;
#define PROVINCE_COMPONENT  0
#define CITY_COMPONENT      1
#define DISTRICT_COMPONENT  2
@protocol BSAreaPickerViewDelegate <NSObject>

-(void)getProvice:(NSString *)provice withcity:(NSString *)city withDistricts:(NSString *)districts;

@optional


@end


@interface BSAreaPickerView : UIView
/**
 *areaTotalArray
 */
@property(nonatomic,strong) NSArray *areaTotalArray;

/**
 *省
 */
@property(nonatomic,strong) NSArray *proviceNameArray;
@property(nonatomic,strong) NSDictionary *proviceCodeDic;
/**
 *市
 */
@property(nonatomic,strong) NSArray *cityNameArray;
@property(nonatomic,strong) NSDictionary *cityCodeDic;
/**
 *区
 */
@property(nonatomic,strong) NSArray *districtsNameArray;
@property(nonatomic,strong) NSDictionary *districtsCodeDic;

/**
 *selectedProvince
 */
@property(nonatomic,strong) NSString *selectedProvince;

@property(nonatomic,strong) id<BSAreaPickerViewDelegate> delegate;

-(void)show;
+(void)remove;

@end
