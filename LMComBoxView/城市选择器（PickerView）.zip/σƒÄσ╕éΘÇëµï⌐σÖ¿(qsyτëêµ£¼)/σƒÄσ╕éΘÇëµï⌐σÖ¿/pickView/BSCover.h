//
//  BSCover.h
//  bs1369
//
//  Created by qsy on 15/11/13.
//  Copyright (c) 2015年 qsy. All rights reserved.
//

#import <UIKit/UIKit.h>
@class BSCover;
@protocol BSCoverDelegate <NSObject>

@optional
//点击蒙版的时候调用
-(void)coverDidClickCover:(BSCover *)cover;

@end
@interface BSCover : UIView
//显示蒙版
+(instancetype)show;
+(void)hide;
@property (nonatomic,assign) BOOL dimBackground;
@property (nonatomic,weak) id<BSCoverDelegate> delegate;
@end
