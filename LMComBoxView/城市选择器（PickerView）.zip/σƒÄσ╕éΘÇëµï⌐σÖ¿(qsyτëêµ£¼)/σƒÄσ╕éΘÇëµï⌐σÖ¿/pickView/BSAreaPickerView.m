//
//  BSAreaPickerView.m
//  bs1369
//
//  Created by qsy on 15/11/10.
//  Copyright (c) 2015年 qsy. All rights reserved.
// 封装pickerView

#import "BSAreaPickerView.h"
#import "BSCover.h"

#define BSToobarHeight 40
#define BSPickerViewHeight 180
#define kWinH self.frame.size.height
#define kWinW self.frame.size.width

#define kPVH (kWinH*0.35>230 ? 260:222)


@interface BSAreaPickerView ()<UIPickerViewDataSource,UIPickerViewDelegate>

@property(nonatomic,strong) UIPickerView *pickerView;
@property(nonatomic,assign) NSInteger pickerViewHeight;
@property(nonatomic,strong) UIView *topView;


@property(nonatomic,strong) NSString *provinceStr;
@property(nonatomic,strong) NSString *cityStr;
@property(nonatomic,strong) NSString *districtsStr;

//       获取到该省行对应的城市的所有数据（包括区）
@property(nonatomic,strong) NSArray *cityArray;

@property(nonatomic,strong) NSString *testStr;
#pragma mark 蒙版实现点击隐藏



@end

@implementation BSAreaPickerView

-(instancetype)initWithFrame:(CGRect)frame{
    if (self=[super initWithFrame:frame]) {
      
        self.backgroundColor=[UIColor whiteColor];
        
        [self setUpTopView];
        [self setUpPickview];
       
    
        [self getPlist];
    }

    return self;
}

#pragma mark 获取plist文件
-(void)getPlist{
    
    //    NSString *path=[[NSBundle mainBundle] pathForResource:@"region" ofType:@"plist"];
    //    _areaDic=[[NSDictionary alloc] initWithContentsOfFile:path];
//    documents的路
    NSArray *fileArray = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *fileStr = [fileArray firstObject];
//    获取到region.plist 的路径
    NSString *regionPath = [fileStr stringByAppendingPathComponent:@"region.plist"];
    _areaTotalArray=[[NSArray alloc] initWithContentsOfFile:regionPath];
#pragma mark  获取省
    NSMutableArray  *proviceNameArray = [[NSMutableArray alloc]init];
    NSMutableDictionary  *proviceCodeDic = [[NSMutableDictionary alloc]init];
    
    for (NSDictionary *dic in _areaTotalArray) {
        [proviceNameArray addObject:dic[@"provinceName"]];
        [proviceCodeDic setObject:dic[@"provincCode"] forKey:[NSString stringWithFormat:@"provice%@",dic[@"provinceName"]]];
    }
    _proviceNameArray = [[NSArray alloc] initWithArray:proviceNameArray];
    _proviceCodeDic = [[NSDictionary alloc] initWithDictionary:proviceCodeDic];
#pragma mark 获取市
    
    NSMutableArray  *cityNameArray = [[NSMutableArray alloc]init];
    NSMutableDictionary  *cityCodeDic = [[NSMutableDictionary alloc]init];
    NSDictionary *dic1 =_areaTotalArray[0];
        for (NSDictionary *dic2 in dic1[@"citys"]) {
            [cityNameArray addObject:dic2[@"cityName"]];
            [cityCodeDic setObject:dic2[@"cityCode"] forKey:[NSString stringWithFormat:@"city%@",dic2[@"cityName"]]];
            
    }
    NSArray *tempArray = dic1[@"citys"];
    NSMutableArray *cityMutableArray = tempArray.mutableCopy;
    _cityArray = [[NSArray alloc] initWithArray:cityMutableArray];
    _cityNameArray = [[NSArray alloc] initWithArray:cityNameArray];
    _cityCodeDic = [[NSDictionary alloc] initWithDictionary:cityCodeDic];
#pragma mark 获取区
    NSMutableArray  *districtsNameArray = [[NSMutableArray alloc]init];
    NSMutableDictionary  *districtsCodeDic = [[NSMutableDictionary alloc]init];
    NSDictionary *dic3 = _areaTotalArray[0][@"citys"][0];
        for (NSDictionary *dic4 in dic3[@"cityRegion"]) {
            [districtsNameArray addObject:dic4[@"regionName"]];
            [districtsCodeDic setObject:dic4[@"regionCode"] forKey:[NSString stringWithFormat:@"district%@",dic4[@"regionName"]]];
            
        }
    
    _districtsNameArray = [[NSArray alloc] initWithArray:districtsNameArray];;
    _districtsCodeDic = [[NSDictionary alloc] initWithDictionary:districtsCodeDic];
//    NSLog(@"%@, ===%@ +++++%@",_proviceNameArray,_cityNameArray,_districtsNameArray);
}

-(void)setUpPickview{
    UIPickerView *pickView=[[UIPickerView alloc] initWithFrame:CGRectMake(0, BSToobarHeight, self.bounds.size.width, BSPickerViewHeight)];
    _pickerView=pickView;
    pickView.delegate=self;
    pickView.dataSource=self;
    pickView.frame=CGRectMake(0, BSToobarHeight, pickView.frame.size.width, pickView.frame.size.height);
    
    [pickView selectRow:0 inComponent:0 animated:YES];
    _pickerViewHeight=pickView.frame.size.height;
    //默认选中的是0
//    _selectedProvince=[_proviceNameArray objectAtIndex:0];
    [self addSubview:pickView];
}

-(void)setUpTopView{
    CGFloat padding=10;
    UIView *topView=[[UIView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, BSToobarHeight)];
    topView.backgroundColor=[UIColor colorWithRed:221.0/255 green:221.0/255 blue:221.0/255 alpha:1.0];
    _topView=topView;
    UIButton *leftBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    UIButton *rightBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    
    [self creatBtn:leftBtn withTitle:@"取消" WithBlackcolor:[UIColor colorWithRed:247.0/255 green:65.0/255 blue:65.0/255 alpha:1.0]];
    [self creatBtn:rightBtn withTitle:@"确定" WithBlackcolor:[UIColor colorWithRed:247.0/255 green:65.0/255 blue:65.0/255 alpha:1.0]];
    leftBtn.tag=0;
    rightBtn.tag=1;
    leftBtn.frame=CGRectMake(padding, 0, 60, BSToobarHeight);
    rightBtn.frame=CGRectMake(topView.bounds.size.width-padding-60, 0, 60, BSToobarHeight);
    [topView addSubview:leftBtn];
    [topView addSubview:rightBtn];
    [self addSubview:topView];
}

-(void)creatBtn:(UIButton *)btn withTitle:(NSString *)title WithBlackcolor:(UIColor *)color{
    [btn setTitle:title forState:UIControlStateNormal];
    [btn setTitleColor:color forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(clickBtn:) forControlEvents:UIControlEventTouchDown];
    
}
-(void)clickBtn:(UIButton *)btn{
    if (btn.tag==0) {
        [BSCover hide];
        [BSAreaPickerView remove];
    }else{
        [BSCover hide];
        [self doneClick];
    }
}

#pragma mark 取消方法
+(void)remove{
    for (UIView *view in [UIApplication sharedApplication].keyWindow.subviews) {
        if ([view isKindOfClass:self]) {
            [view removeFromSuperview];
        }
    }

}
#pragma mark 确定的方法
-(void)doneClick
{
//    选择各个区的行数
    NSInteger provinceIndex = [self.pickerView selectedRowInComponent: 0];
    NSInteger cityIndex = [self.pickerView selectedRowInComponent: 1];
    NSInteger districtIndex = [self.pickerView selectedRowInComponent: 2];
//    对应的文字
    NSString *provinceStr = [_proviceNameArray objectAtIndex: provinceIndex];
    NSString *cityStr = [_cityNameArray objectAtIndex: cityIndex];
    NSString *districtStr = [_districtsNameArray objectAtIndex:districtIndex];
    
    if ([provinceStr isEqualToString: cityStr]) {
        cityStr = @"";
    } else if ([cityStr isEqualToString: districtStr]) {
        districtStr = @"";
    }
    
#pragma mark 确定之后 用代理实现选择地址的传递
    [self.delegate getProvice:provinceStr withcity:cityStr withDistricts:districtStr];
    [self removeFromSuperview];
   
    
}

#pragma mark 数据源方法
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 3;
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    NSInteger count=0;
    switch (component) {
        case 0:
            //获取省的count
            count=_proviceNameArray.count;
            break;
            case 1:
            //获取市的count
            count=_cityNameArray.count;
            break;
            case 2:
            //获取地区的count
            count=_districtsNameArray.count;
            break;
            
        default:
            break;
    }
    return count;
}

-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    NSString *rowTitle=nil;
    switch (component) {
        case 0:
            //获取省的count
            rowTitle=_proviceNameArray[row];
            self.provinceStr=_proviceNameArray[row];
            break;
        case 1:
            //获取市的count
            rowTitle=_cityNameArray[row];
            self.cityStr=_cityNameArray[row];
            break;
        case 2:
            //获取地区的count
            rowTitle=_districtsNameArray[row];
            self.districtsStr=_districtsNameArray[row];
            break;
            
        default:
            break;
    }
 
    return rowTitle;
}
#pragma mark 选中的地址
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    
    if (component == PROVINCE_COMPONENT) {
        NSArray *cityArray = _areaTotalArray[row][@"citys"];
        NSMutableArray *cityMutableArray = cityArray.mutableCopy;
        _cityArray = [[NSArray alloc]initWithArray:cityMutableArray];
//       获取到该省行对应的城市的所有数据（包括区）
        NSMutableArray  *cityNameArray = [[NSMutableArray alloc]init];
        NSMutableDictionary  *cityCodeDic = [[NSMutableDictionary alloc]init];
        NSDictionary *dic1 =_areaTotalArray[row];
        for (NSDictionary *dic2 in dic1[@"citys"]) {
            [cityNameArray addObject:dic2[@"cityName"]];
            [cityCodeDic setObject:dic2[@"cityCode"] forKey:[NSString stringWithFormat:@"city%@",dic2[@"cityName"]]];
        }
        _cityNameArray = [[NSArray alloc] initWithArray:cityNameArray];
        _cityCodeDic = [[NSDictionary alloc] initWithDictionary:cityCodeDic];
//      移除之前地区的数据内容:根据市来调动对应的地区
        NSMutableArray  *districtsNameArray = [[NSMutableArray alloc]init];
        NSMutableDictionary  *districtsCodeDic = [[NSMutableDictionary alloc]init];
        NSDictionary *dic3 = _areaTotalArray[row][@"citys"][0];
        for (NSDictionary *dic4 in dic3[@"cityRegion"]) {
            [districtsNameArray addObject:dic4[@"regionName"]];
            [districtsCodeDic setObject:dic4[@"regionCode"] forKey:[NSString stringWithFormat:@"district%@",dic4[@"regionName"]]];
            
        }
        _districtsNameArray = [[NSArray alloc] initWithArray:districtsNameArray];;
        _districtsCodeDic = [[NSDictionary alloc] initWithDictionary:districtsCodeDic];
        
        [self.pickerView selectRow: 0 inComponent: CITY_COMPONENT animated: YES];
        [self.pickerView  selectRow: 0 inComponent: DISTRICT_COMPONENT animated: YES];
        [self.pickerView  reloadComponent: CITY_COMPONENT];
        [self.pickerView  reloadComponent: DISTRICT_COMPONENT];
        
        
        
    } else if (component==CITY_COMPONENT){
//    获取到选择哪行的市
        NSMutableArray  *districtsNameArray = [[NSMutableArray alloc]init];
        NSMutableDictionary  *districtsCodeDic = [[NSMutableDictionary alloc]init];
        NSDictionary *dic3 = _cityArray[row];
        for (NSDictionary *dic4 in dic3[@"cityRegion"]) {
            [districtsNameArray addObject:dic4[@"regionName"]];
            [districtsCodeDic setObject:dic4[@"regionCode"] forKey:[NSString stringWithFormat:@"district%@",dic4[@"regionName"]]];
            
        }
        _districtsNameArray = [[NSArray alloc] initWithArray:districtsNameArray];;
        _districtsCodeDic = [[NSDictionary alloc] initWithDictionary:districtsCodeDic];
        
        [self.pickerView selectRow: 0 inComponent: DISTRICT_COMPONENT animated: YES];
        [self.pickerView reloadComponent: DISTRICT_COMPONENT];
    }
    
    
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view
{
    UILabel *myView=nil;
    
    if (component == PROVINCE_COMPONENT) {
        myView = [[UILabel alloc] initWithFrame:CGRectMake(0.0, 0.0, 78, 30)] ;
        myView.textAlignment = NSTextAlignmentCenter;
        myView.text = [_proviceNameArray objectAtIndex:row];
        myView.font = [UIFont systemFontOfSize:15];
        myView.backgroundColor = [UIColor clearColor];
        self.provinceStr=[_proviceNameArray objectAtIndex:row];
        
    }
    else if (component == CITY_COMPONENT) {
        myView = [[UILabel alloc] initWithFrame:CGRectMake(0.0, 0.0, 95, 30)] ;
        myView.textAlignment = NSTextAlignmentCenter;
        myView.text = [_cityNameArray objectAtIndex:row];
        myView.font = [UIFont systemFontOfSize:15];
        myView.backgroundColor = [UIColor clearColor];
       self.cityStr=[_cityNameArray objectAtIndex:row];
       
    }
    else {
        myView = [[UILabel alloc] initWithFrame:CGRectMake(0.0, 0.0, 110, 30)] ;
        myView.textAlignment = NSTextAlignmentCenter;
        myView.text = [_districtsNameArray objectAtIndex:row];
        myView.font = [UIFont systemFontOfSize:15];
        myView.backgroundColor = [UIColor clearColor];
        self.districtsStr=[_districtsNameArray objectAtIndex:row];
      
    }
   
    return myView;
}


#pragma mark 展示
-(void)show{
     [[UIApplication sharedApplication].keyWindow addSubview:self];
   
}


@end



















