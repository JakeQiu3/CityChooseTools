//
//  ViewController.m
//  城市选择器
//
//  Created by qsy on 15/12/31.
//  Copyright © 2015年 qsy. All rights reserved.
//

#import "ViewController.h"
#import "BSAreaPickerView.h"
#import "BSCover.h"
#define screenW [UIScreen mainScreen].bounds.size.width
@interface ViewController ()<BSCoverDelegate,BSAreaPickerViewDelegate>
@property(nonatomic,assign) CGFloat keyH;
@property(nonatomic,strong) NSString *addr;
@property(nonatomic,strong) UIButton *btn;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self convertTxtToPlist];//转换txt为plist
    self.btn=[UIButton buttonWithType:UIButtonTypeCustom];
    self.btn.frame=CGRectMake(50, 100, 250, 40);
    self.btn.backgroundColor=[UIColor greenColor];
    [_btn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [self.view addSubview:self.btn];
    [self.btn addTarget:self action:@selector(showPickerView) forControlEvents:UIControlEventTouchUpInside];
    [self.btn setTitle:@"请选择城市" forState:UIControlStateNormal];
}

- (void)convertTxtToPlist {
    NSString *filePath = [[NSBundle mainBundle]pathForResource:@"region" ofType:@"txt"];
    //定义字符串接收从txt文件读取的内容
    NSString *str = [[NSString alloc] initWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
    //将字符串转为nsdata类型
    NSData *data = [str dataUsingEncoding:NSUTF8StringEncoding];
    //将nsdata类型转为NSDictionary
    NSArray *TempArray = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
    NSMutableArray *TotalArray = [NSMutableArray array];
    for (NSDictionary *dic in TempArray) {
        if ([dic[@"parentcode"] isEqualToString:@"0"]) {
            //           省字典
            NSMutableDictionary *proviceDic = @{}.mutableCopy;
            [TotalArray addObject:proviceDic];
            [proviceDic setObject:dic[@"name"] forKey:@"provinceName"];
            [proviceDic setObject:dic[@"code"] forKey:@"provincCode"];
            [proviceDic setObject:[[NSMutableArray alloc]init] forKey:@"citys"];
        }
    }
    
    
    for (NSDictionary *dic1 in TotalArray) {
        for (NSDictionary *dic2 in TempArray) {
            if ([dic1[@"provincCode"] isEqualToString:dic2[@"parentcode"]]) {
                //           市的字典
                NSMutableDictionary *cityDic = @{}.mutableCopy;
                [dic1[@"citys"] addObject:cityDic];
                [cityDic setObject:dic2[@"name"] forKey:@"cityName"];
                [cityDic setObject:dic2[@"code"] forKey:@"cityCode"];
                [cityDic setObject:[[NSMutableArray alloc]init] forKey:@"cityRegion"];
            }
        }
    }
    
    for (NSDictionary *dic1 in TotalArray) {
        for (NSDictionary *dic2 in TempArray) {
            for (NSDictionary *dic3 in dic1[@"citys"]) {
                if ([dic3[@"cityCode"] isEqualToString:dic2[@"parentcode"]]) {
                    //           区的字典
                    NSMutableDictionary *cityRegionDic = @{}.mutableCopy;
                    [dic3[@"cityRegion"] addObject:cityRegionDic];
                    [cityRegionDic setObject:dic2[@"name"] forKey:@"regionName"];
                    [cityRegionDic setObject:dic2[@"code"] forKey:@"regionCode"];
                }
            }
            
        }
    }
    
    NSArray *paths=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    NSString *plistPath = [paths firstObject];
    //得到完整的文件名
    NSString *filename=[plistPath stringByAppendingPathComponent:@"region.plist"];
//    NSLog(@"文件路径：%@",filename);
    //输入写入
    
    [TotalArray writeToFile:filename atomically:YES];
//    NSLog(@"TotalArray:%@",TotalArray);
}

#pragma mark 选择城市
#pragma mark 调用pickerview
-(void)showPickerView{
    BSCover *cover=[BSCover show];
    cover.dimBackground=YES;
    cover.delegate=self;
    if(screenW<=320){
        self.keyH=220;
    }else{
        self.keyH=271;
    }
    BSAreaPickerView *pickerView=[[BSAreaPickerView alloc]initWithFrame:CGRectMake(0, self.view.frame.size.height-self.keyH, self.view.frame.size.width, self.keyH)];
    pickerView.delegate=self;
    //结束编辑
    [self.view endEditing:YES];
    [pickerView show];
}

-(void)getProvice:(NSString *)provice withcity:(NSString *)city withDistricts:(NSString *)districts{
    
   self.addr=[NSString stringWithFormat:@"%@%@%@",provice,city,districts];
    [self.btn setTitle:self.addr forState:UIControlStateNormal];
    
}



#pragma mark 实现点击蒙版的方法
-(void)coverDidClickCover:(BSCover *)cover{
    //隐藏蒙版
    [BSAreaPickerView remove];
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
