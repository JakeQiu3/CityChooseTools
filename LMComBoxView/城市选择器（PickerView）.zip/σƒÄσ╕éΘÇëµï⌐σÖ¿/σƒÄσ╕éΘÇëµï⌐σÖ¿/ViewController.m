//
//  ViewController.m
//  城市选择器
//
//  Created by qsy on 15/12/31.
//  Copyright © 2015年 qsy. All rights reserved.
//

#import "ViewController.h"
#import "BSAreaPickerView.h"
#import "BSCover.h"
#define screenW [UIScreen mainScreen].bounds.size.width
@interface ViewController ()<BSCoverDelegate,BSAreaPickerViewDelegate>
@property(nonatomic,assign) CGFloat keyH;
@property(nonatomic,strong) NSString *addr;
@property(nonatomic,strong) UIButton *btn;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.btn=[UIButton buttonWithType:UIButtonTypeCustom];
    self.btn.frame=CGRectMake(50, 100, 250, 40);
    self.btn.backgroundColor=[UIColor greenColor];
    [_btn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [self.view addSubview:self.btn];
    [self.btn addTarget:self action:@selector(showPickerView) forControlEvents:UIControlEventTouchUpInside];
    [self.btn setTitle:@"请选择城市" forState:UIControlStateNormal];
    
}
#pragma mark 选择城市
#pragma mark 调用pickerview
-(void)showPickerView{
    BSCover *cover=[BSCover show];
    cover.dimBackground=YES;
    cover.delegate=self;
    if(screenW<=320){
        self.keyH=220;
    }else{
        self.keyH=271;
    }
    BSAreaPickerView *pickerView=[[BSAreaPickerView alloc]initWithFrame:CGRectMake(0, self.view.frame.size.height-self.keyH, self.view.frame.size.width, self.keyH)];
    pickerView.delegate=self;
    //结束编辑
    [self.view endEditing:YES];
    [pickerView show];
}

-(void)getProvice:(NSString *)provice withcity:(NSString *)city withDistricts:(NSString *)districts{
    
   self.addr=[NSString stringWithFormat:@"%@%@%@",provice,city,districts];
    [self.btn setTitle:self.addr forState:UIControlStateNormal];
    
}



#pragma mark 实现点击蒙版的方法
-(void)coverDidClickCover:(BSCover *)cover{
    //隐藏蒙版
    [BSAreaPickerView remove];
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
