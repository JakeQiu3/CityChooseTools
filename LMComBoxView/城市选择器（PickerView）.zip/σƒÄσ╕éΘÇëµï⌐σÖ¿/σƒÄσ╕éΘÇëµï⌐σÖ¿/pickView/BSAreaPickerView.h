//
//  BSAreaPickerView.h
//  bs1369
//
//  Created by qsy on 15/11/10.
//  Copyright (c) 2015年 bsw. All rights reserved.
//

#import <UIKit/UIKit.h>
@class BSAreaPickerView;
#define PROVINCE_COMPONENT  0
#define CITY_COMPONENT      1
#define DISTRICT_COMPONENT  2
@protocol BSAreaPickerViewDelegate <NSObject>

-(void)getProvice:(NSString *)provice withcity:(NSString *)city withDistricts:(NSString *)districts;

@optional


@end


@interface BSAreaPickerView : UIView
/**
 *省
 */
@property(nonatomic,strong) NSArray *proviceArray;
/**
 *市
 */
@property(nonatomic,strong) NSArray *cityArray;
/**
 *区
 */
@property(nonatomic,strong) NSArray *districtsArray;
/**
 *areaDic
 */
@property(nonatomic,strong) NSDictionary *areaDic;
/**
 *areaDic
 */
@property(nonatomic,strong) NSString *selectedProvince;

@property(nonatomic,strong) id<BSAreaPickerViewDelegate> delegate;

-(void)show;
+(void)remove;

@end
