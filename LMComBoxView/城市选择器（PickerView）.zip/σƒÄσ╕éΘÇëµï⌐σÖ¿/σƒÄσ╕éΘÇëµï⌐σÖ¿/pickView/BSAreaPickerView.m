//
//  BSAreaPickerView.m
//  bs1369
//
//  Created by qsy on 15/11/10.
//  Copyright (c) 2015年 bsw. All rights reserved.
// 封装pickerView

#import "BSAreaPickerView.h"
#import "BSCover.h"

#define BSToobarHeight 40
#define BSPickerViewHeight 180
#define kWinH self.frame.size.height
#define kWinW self.frame.size.width

#define kPVH (kWinH*0.35>230 ? 260:222)


@interface BSAreaPickerView ()<UIPickerViewDataSource,UIPickerViewDelegate>

@property(nonatomic,strong) UIPickerView *pickerView;
@property(nonatomic,assign) NSInteger pickerViewHeight;
@property(nonatomic,strong) UIView *topView;


@property(nonatomic,strong) NSString *provinceStr;
@property(nonatomic,strong) NSString *cityStr;
@property(nonatomic,strong) NSString *districtsStr;



@property(nonatomic,strong) NSString *testStr;
#pragma mark 蒙版实现点击隐藏



@end

@implementation BSAreaPickerView

-(instancetype)initWithFrame:(CGRect)frame{
    if (self=[super initWithFrame:frame]) {
      
        self.backgroundColor=[UIColor whiteColor];
        
        [self setUpTopView];
        [self setUpPickview];
       
    
        [self getPlist];
    }

    return self;
}


#pragma mark 获取plist文件
-(void)getPlist{

//    NSString *filePath = [[NSBundle mainBundle]pathForResource:@"region" ofType:@"plist"];
    
    NSString *path=[[NSBundle mainBundle] pathForResource:@"area" ofType:@"plist"];
    _areaDic=[[NSDictionary alloc] initWithContentsOfFile:path];

#pragma mark  keys
    NSArray *comPonets=[_areaDic allKeys];//本身是无序的
    NSArray *sorteArray=[comPonets sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
        if ([obj1 integerValue] > [obj2 integerValue]) {
            return (NSComparisonResult)NSOrderedDescending;
        }
        if ([obj1 integerValue] < [obj2 integerValue]) {
            return (NSComparisonResult)NSOrderedAscending;
        }
        return (NSComparisonResult)NSOrderedSame;
    }];
    
    NSMutableArray *provinceTmp=[[NSMutableArray alloc] init];
    for (int i=0; i<[sorteArray count]; i++) {
        NSString *Index=[sorteArray objectAtIndex:i];
        NSArray *tmp=[[_areaDic objectForKey:Index] allKeys];
        [provinceTmp addObject:[tmp objectAtIndex:0]];
    }
#pragma mark  获取省
    
    _proviceArray=[[NSArray alloc] initWithArray:provinceTmp];
    NSString *index=[sorteArray objectAtIndex:0];
    NSString *selected=[_proviceArray objectAtIndex:0];
    NSDictionary *dic=[NSDictionary dictionaryWithDictionary:[[_areaDic objectForKey:index] objectForKey:selected]];
    NSArray *cityArray=[dic allKeys];
#pragma mark 获取市
    NSDictionary *cityDic=[NSDictionary dictionaryWithDictionary:[dic objectForKey:[cityArray objectAtIndex:0]]];
    _cityArray=[[NSArray alloc] initWithArray:[cityDic allKeys]];
    NSString *selectedCity=[_cityArray objectAtIndex:0];
#pragma mark 获取区
    _districtsArray=[[NSArray alloc] initWithArray:[cityDic objectForKey:selectedCity]];
  
    NSLog(@"_cityArray:%@,_districtsArray:%@",_cityArray,_districtsArray);
    
}

-(void)setUpPickview{
    UIPickerView *pickView=[[UIPickerView alloc] initWithFrame:CGRectMake(0, BSToobarHeight, self.bounds.size.width, BSPickerViewHeight)];
    _pickerView=pickView;
    pickView.delegate=self;
    pickView.dataSource=self;
    pickView.frame=CGRectMake(0, BSToobarHeight, pickView.frame.size.width, pickView.frame.size.height);
    
    [pickView selectRow:0 inComponent:0 animated:YES];
    _pickerViewHeight=pickView.frame.size.height;
    //默认选中的是0
    _selectedProvince=[_proviceArray objectAtIndex:0];
    [self addSubview:pickView];
}

-(void)setUpTopView{
    CGFloat padding=10;
    UIView *topView=[[UIView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, BSToobarHeight)];
    topView.backgroundColor=[UIColor colorWithRed:221.0/255 green:221.0/255 blue:221.0/255 alpha:1.0];
    _topView=topView;
    UIButton *leftBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    UIButton *rightBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    
    [self creatBtn:leftBtn withTitle:@"取消" WithBlackcolor:[UIColor colorWithRed:247.0/255 green:65.0/255 blue:65.0/255 alpha:1.0]];
    [self creatBtn:rightBtn withTitle:@"确定" WithBlackcolor:[UIColor colorWithRed:247.0/255 green:65.0/255 blue:65.0/255 alpha:1.0]];
    leftBtn.tag=0;
    rightBtn.tag=1;
    leftBtn.frame=CGRectMake(padding, 0, 60, BSToobarHeight);
    rightBtn.frame=CGRectMake(topView.bounds.size.width-padding-60, 0, 60, BSToobarHeight);
    [topView addSubview:leftBtn];
    [topView addSubview:rightBtn];
    [self addSubview:topView];
}

-(void)creatBtn:(UIButton *)btn withTitle:(NSString *)title WithBlackcolor:(UIColor *)color{
    [btn setTitle:title forState:UIControlStateNormal];
    [btn setTitleColor:color forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(clickBtn:) forControlEvents:UIControlEventTouchDown];
    
}
-(void)clickBtn:(UIButton *)btn{
    if (btn.tag==0) {
        [BSCover hide];
        [BSAreaPickerView remove];
    }else{
        [BSCover hide];
        [self doneClick];
    }
}

#pragma mark 取消方法
+(void)remove{
    for (UIView *view in [UIApplication sharedApplication].keyWindow.subviews) {
        if ([view isKindOfClass:self]) {
            [view removeFromSuperview];
        }
    }

}
#pragma mark 确定的方法
-(void)doneClick
{
//    选择各个区的行数
    NSInteger provinceIndex = [self.pickerView selectedRowInComponent: 0];
    NSInteger cityIndex = [self.pickerView selectedRowInComponent: 1];
    NSInteger districtIndex = [self.pickerView selectedRowInComponent: 2];
//    对应的文字
    NSString *provinceStr = [self.proviceArray objectAtIndex: provinceIndex];
    NSString *cityStr = [self.cityArray objectAtIndex: cityIndex];
    NSString *districtStr = [self.districtsArray objectAtIndex:districtIndex];
    
    if ([provinceStr isEqualToString: cityStr]) {
        cityStr = @"";
    } else if ([cityStr isEqualToString: districtStr]) {
        districtStr = @"";
    }
    
#pragma mark 确定之后 用代理实现选择地址的传递
    [self.delegate getProvice:provinceStr withcity:cityStr withDistricts:districtStr];
   
    [self removeFromSuperview];
   
    
}

#pragma mark 数据源方法
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 3;
}
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    NSInteger count=0;
    switch (component) {
        case 0:
            //获取省的count
            count=_proviceArray.count;
            break;
            case 1:
            //获取市的count
            count=_cityArray.count;
            break;
            case 2:
            //获取地区的count
            count=_districtsArray.count;
            break;
            
        default:
            break;
    }
    return count;
}

-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    NSString *rowTitle=nil;
    switch (component) {
        case 0:
            //获取省的count
            rowTitle=_proviceArray[row];
            self.provinceStr=_proviceArray[row];
            break;
        case 1:
            //获取市的count
            rowTitle=_cityArray[row];
            self.cityStr=_cityArray[row];
            break;
        case 2:
            //获取地区的count
            rowTitle=_districtsArray[row];
            self.districtsStr=_districtsArray[row];
            break;
            
        default:
            break;
    }
 
    return rowTitle;
}
#pragma mark 选中的地址
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    if (component==0) {
        self.selectedProvince=[self.proviceArray objectAtIndex:row];
        NSDictionary *tmp=[NSDictionary dictionaryWithDictionary:[_areaDic objectForKey:[NSString stringWithFormat:@"%ld",row]]];
        NSDictionary *dic=[NSDictionary dictionaryWithDictionary:[tmp objectForKey:self.selectedProvince]];
        NSArray *cityArray=[dic allKeys];
        NSArray *sortedArray=[cityArray sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
            if ([obj1 integerValue] > [obj2 integerValue]) {
                return (NSComparisonResult)NSOrderedDescending;//递减
            }
            
            if ([obj1 integerValue] < [obj2 integerValue]) {
                return (NSComparisonResult)NSOrderedAscending;//上升
            }
           
            
            return (NSComparisonResult)NSOrderedSame;
        }];
        
        NSMutableArray *array=[[NSMutableArray alloc] init];
        for (int i=0; i<sortedArray.count; i++) {
            NSString *index=[sortedArray objectAtIndex:i];
            NSArray *temp=[[dic objectForKey:index] allKeys];
            [array addObject:[temp objectAtIndex:0]];
        }
        NSLog(@"前_cityArray :%@,%p",[_cityArray class],&_cityArray);
        _cityArray=[[NSArray alloc] initWithArray:array];
        NSLog(@"后_cityArray :%@，,%p",[_cityArray class],&_cityArray);
        NSDictionary *cityDic = [dic objectForKey: [sortedArray objectAtIndex: 0]];
        self.districtsArray = [[NSArray alloc] initWithArray: [cityDic objectForKey: [self.cityArray objectAtIndex: 0]]];
        [self.pickerView selectRow: 0 inComponent: CITY_COMPONENT animated: YES];
        [self.pickerView  selectRow: 0 inComponent: DISTRICT_COMPONENT animated: YES];
        [self.pickerView  reloadComponent: CITY_COMPONENT];
        [self.pickerView  reloadComponent: DISTRICT_COMPONENT];
        
        
        
    }else if (component==CITY_COMPONENT){
        
        NSString *provinceIndex = [NSString stringWithFormat: @"%lu", [_proviceArray indexOfObject: _selectedProvince]];

        NSDictionary *tmp = [NSDictionary dictionaryWithDictionary: [self.areaDic objectForKey: provinceIndex]];
        
        NSDictionary *dic = [NSDictionary dictionaryWithDictionary: [tmp objectForKey: self.selectedProvince]];
        NSArray *dicKeyArray = [dic allKeys];
        NSArray *sortedArray = [dicKeyArray sortedArrayUsingComparator: ^(id obj1, id obj2) {
            
            if ([obj1 integerValue] > [obj2 integerValue]) {
                return (NSComparisonResult)NSOrderedDescending;
            }
            
            if ([obj1 integerValue] < [obj2 integerValue]) {
                return (NSComparisonResult)NSOrderedAscending;
            }
            return (NSComparisonResult)NSOrderedSame;
        }];
#pragma mark 大于0 城市选择city 的时候正常，小于0内存溢出
        if(sortedArray.count>0){
            NSDictionary *cityDic = [NSDictionary dictionaryWithDictionary:[dic objectForKey: [sortedArray objectAtIndex:row]]];
            NSArray *cityKeyArray = [cityDic allKeys];
            
            self.districtsArray = [[NSArray alloc] initWithArray: [cityDic objectForKey: [cityKeyArray objectAtIndex:0]]];
        }
        
        [self.pickerView selectRow: 0 inComponent: DISTRICT_COMPONENT animated: YES];
        [self.pickerView reloadComponent: DISTRICT_COMPONENT];
    }
    
    
}



- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view
{
    UILabel *myView=nil;
    
    if (component == PROVINCE_COMPONENT) {
        myView = [[UILabel alloc] initWithFrame:CGRectMake(0.0, 0.0, 78, 30)] ;
        myView.textAlignment = NSTextAlignmentCenter;
        myView.text = [self.proviceArray objectAtIndex:row];
        myView.font = [UIFont systemFontOfSize:15];
        myView.backgroundColor = [UIColor clearColor];
        self.provinceStr=[self.proviceArray objectAtIndex:row];
        
    }
    else if (component == CITY_COMPONENT) {
        myView = [[UILabel alloc] initWithFrame:CGRectMake(0.0, 0.0, 95, 30)] ;
        myView.textAlignment = NSTextAlignmentCenter;
        myView.text = [self.cityArray objectAtIndex:row];
        myView.font = [UIFont systemFontOfSize:15];
        myView.backgroundColor = [UIColor clearColor];
       self.cityStr=[self.cityArray objectAtIndex:row];
       
    }
    else {
        myView = [[UILabel alloc] initWithFrame:CGRectMake(0.0, 0.0, 110, 30)] ;
        myView.textAlignment = NSTextAlignmentCenter;
        myView.text = [self.districtsArray objectAtIndex:row];
        myView.font = [UIFont systemFontOfSize:15];
        myView.backgroundColor = [UIColor clearColor];
        self.districtsStr=[self.districtsArray objectAtIndex:row];
      
    }
   
    return myView;
}


#pragma mark 展示
-(void)show{
     [[UIApplication sharedApplication].keyWindow addSubview:self];
   
}


@end



















