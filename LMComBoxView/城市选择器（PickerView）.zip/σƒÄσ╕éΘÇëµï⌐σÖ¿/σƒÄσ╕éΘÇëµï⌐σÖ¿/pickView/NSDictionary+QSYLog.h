//
//  NSDictionary+QSYLog.h
//  weibo
//
//  Created by qsy on 15/7/29.
//  Copyright (c) 2015年 QSY. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (QSYLog)

@end

@interface NSArray (QSYLog)

@end