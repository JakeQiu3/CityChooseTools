//
//  ViewController.m
//  TLCityPickerDemo
//
//  Created by qsy on 15/11/5.
//  Copyright © 2015年 qsy. All rights reserved.
//

#import "ViewController.h"
#import "TLCityPickerController.h"

@interface ViewController () <TLCityPickerDelegate>

@property (weak, nonatomic) IBOutlet UIButton *cityPickerButton;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (IBAction)cityPickerButtonDown:(UIButton *)sender {
    TLCityPickerController *cityPickerVC = [[TLCityPickerController alloc] init];
    [cityPickerVC setDelegate:self];
    
#pragma mark 本地城市 定位城市 
    cityPickerVC.locationCityID = @"1400010000";
#pragma mark 最近访问城市
//    cityPickerVC.commonCitys = [[NSMutableArray alloc] initWithArray: @[@"1400010000", @"100010000"]];        // 最近访问城市，如果不设置，将自动管理
#pragma mark 热门城市
    cityPickerVC.hotCitys = @[@"100010000", @"200010000", @"300210000", @"600010000", @"300110000"];
    
    [self presentViewController:[[UINavigationController alloc] initWithRootViewController:cityPickerVC] animated:YES completion:^{
    }];
}

#pragma mark - TLCityPickerDelegate
- (void) cityPickerController:(TLCityPickerController *)cityPickerViewController didSelectCity:(TLCity *)city
{
    [self.cityPickerButton setTitle:city.cityName forState:UIControlStateNormal];
    [cityPickerViewController dismissViewControllerAnimated:YES completion:^{
        
    }];
}

- (void) cityPickerControllerDidCancel:(TLCityPickerController *)cityPickerViewController
{
    [cityPickerViewController dismissViewControllerAnimated:YES completion:^{
        
    }];
}

@end
