//
//  AppDelegate.h
//  TLCityPickerDemo
//
//  Created by qsy on 15/11/5.
//  Copyright © 2015年 qsy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

