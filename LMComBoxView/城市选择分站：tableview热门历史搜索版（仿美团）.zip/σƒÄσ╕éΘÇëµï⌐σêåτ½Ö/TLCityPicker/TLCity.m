//
//  TLCity.m
//  TLCityPickerDemo
//
//  Created by qsy on 15/11/5.
//  Copyright © 2015年 qsy. All rights reserved.
//

#import "TLCity.h"

@implementation TLCity

@end

#pragma mark - TLCityGroup
@implementation TLCityGroup

- (NSMutableArray *) arrayCitys
{
    if (_arrayCitys == nil) {
        _arrayCitys = [[NSMutableArray alloc] init];
    }
    return _arrayCitys;
}

@end
